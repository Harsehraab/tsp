import numpy as np
import random

def euclidean_distance(city1, city2):
    return np.linalg.norm(city1 - city2)

def initialize_pheromones(num_cities):
    return np.ones((num_cities, num_cities))

def ant_tour(pheromones, distances, alpha, beta):
    num_cities = len(pheromones)
    start_city = random.randint(0, num_cities - 1)
    unvisited_cities = list(range(num_cities))
    unvisited_cities.remove(start_city)
    
    tour = [start_city]
    current_city = start_city
    
    while unvisited_cities:
        next_city = max(unvisited_cities, key=lambda city: pheromones[current_city][city]**alpha * (1 / distances[current_city][city])**beta)
        tour.append(next_city)
        unvisited_cities.remove(next_city)
        current_city = next_city
    
    return tour

def update_pheromones(pheromones, tours, distances, rho, Q):
    pheromones *= (1 - rho)
    for tour in tours:
        for i in range(len(tour) - 1):
            city1 = tour[i]
            city2 = tour[i + 1]
            pheromones[city1][city2] += Q / distances[city1][city2]
            pheromones[city2][city1] += Q / distances[city2][city1]

def main():
    distance_type = input().strip()
    num_cities = int(input().strip())
    
    cities = []
    for _ in range(num_cities):
        x, y = map(float, input().split())
        cities.append(np.array([x, y]))
    
    distances = np.zeros((num_cities, num_cities))
    for i in range(num_cities):
        distances[i] = list(map(float, input().split()))
    
    alpha = 1
    beta = 5
    rho = 0.1
    Q = 1
    
    pheromones = initialize_pheromones(num_cities)
    
    best_tour = None
    best_tour_length = float('inf')
    
    for _ in range(1000):  # Number of iterations
        ant_tours = [ant_tour(pheromones, distances, alpha, beta) for _ in range(num_cities)]
        tour_lengths = [sum(distances[tour[i]][tour[i + 1]] for i in range(num_cities - 1)) + distances[tour[-1]][tour[0]] for tour in ant_tours]
        
        for i, length in enumerate(tour_lengths):
            if length < best_tour_length:
                best_tour_length = length
                best_tour = ant_tours[i]
        
        update_pheromones(pheromones, ant_tours, distances, rho, Q)
    
    print("PATH REPRESENTATION OF TOUR")
    print(" ".join(map(str, best_tour)))

if __name__ == "__main__":
    main()

