#!/bin/bash

python3 x.py
